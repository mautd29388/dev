<!-- Section Header  -->
<div class="section-header <?php echo join($parent_class, ' '); ?>">
	<h2 class="section-title"><span><?php echo apply_filters('mTheme_shortcode_title', $atts['title']) ?></span></h2>
	<div class="section-subtitle"><?php echo apply_filters('mTheme_shortcode_subtitle', $content); ?></div>
</div>