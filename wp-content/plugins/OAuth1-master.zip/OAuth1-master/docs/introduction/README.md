# Introduction

* [Why OAuth?](OAuth.md)
* [Why OAuth 1.0a?](OAuth-1.md)
* [Setup](Setup.md)